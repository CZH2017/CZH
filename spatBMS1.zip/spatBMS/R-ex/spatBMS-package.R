### Name: spatBMS-package
### Title: Bayesian Model Averaging with uncertain Spatial Effects 0.0.0
### Aliases: spatBMS-package spatBMS
### Keywords: package

### ** Examples

  library(BMS)
  data(dataBoston); data(WL.boston)
  # estimating a standard MC3 chain 
  bma1=spatFilt.bms(X.data=dataBoston,WList=WL.boston,burn=1e05,iter=1e05,
              nmodel=100,mcmc="bd",g="bric",mprior="random",mprior.size=(ncol(dataBoston)-1)/2)
  
  estimates.bma(bma1)            
  coef(bma1,exact=TRUE, std.coefs=TRUE) #standard coefficients based on exact likelihoods of the 100 best models
  # look at posterior inclusion probabilities of weight matrices
  pmpW.bma(bma1)
  
  # test for remaining spatial residual autocorrelation
  library(spdep)
  data(boston.soi)
  moran=moranTest.bma(bma1,W=nb2listw(boston.soi))           




