### Name: dataBoston
### Title: Corrected Boston Housing Data
### Aliases: dataBoston WL.boston
### Keywords: datasets

### ** Examples

data(dataBoston)




