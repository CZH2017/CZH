### Name: moranTest.bma
### Title: Moran's I test for spatial residual autocorrelation for models
###   with largest posterior support
### Aliases: moranTest.bma
### Keywords: utilities

### ** Examples


  #sample a bma object:
   data(dataBoston);data(boston.soi);data(WL.boston); 
   bma1=spatFilt.bms(X.data=dataBoston,WList=WL.boston,burn=1e04,iter=1e04,nmodel=100)
   mTest=moranTest.bma(bma1,variants="double",W=nb2listw(boston.soi))           

  
  #extract p-values
  pvalueMat=cbind(sapply(mTest$moran,function(x) x$p.value),sapply(mTest$moranEV,function(x) x$p.value))

  
  #compare boxplots
  Colours=c("#1B9E77", "#D95F02", "#7570B3", "#E7298A", "#66A61E" ,"#E6AB02", "#A6761D", "#666666")
  par(mfrow=c(1,2))
  boxplot(pvalueMat[,1],main="Box plot of p-values \n OLS-regression",xaxt="n",col=Colours[3],outline=FALSE,ylim=c(0,1))
  grid()
  boxplot(pvalueMat[,2],main="Box plot of p-values \n Eigenvector augmented regression",xaxt="n",col=Colours[3],outline=FALSE,ylim=c(0,1))
  grid()
  par(mfrow=c(1,1))




