### Name: spatFilt.bms
### Title: Bayesian Model Sampling and Averaging with uncertain Spatial
###   Effects
### Aliases: spatFilt.bms
### Keywords: models

### ** Examples

  library(BMS)
  data(dataBoston); data(WL.boston)
  #estimating a standard MC3 chain 
  bma1=spatFilt.bms(X.data=dataBoston,WList=WL.boston,burn=1e05,iter=1e05,
              nmodel=100,mcmc="bd",g="bric",mprior="random",mprior.size=(ncol(dataBoston)-1)/2)
              
  coef(bma1,exact=TRUE, std.coefs=TRUE) #standard coefficients based on exact likelihoods of the 100 best models
  
  #suppressing user-interactive output and  using a customized starting value (the null model)
  bma2 = spatFilt.bms(dataBoston,WList=WL.boston,burn=1000, iter=2000, nmodel=10, 
                      start.value=rep(0,ncol(dataBoston)),user.int=FALSE,)
  coef(bma2)
  
  #MC3 chain with the bric prior, saving only the 20 best models, and an alternative sampling procedure; putting a log entry to console every 1000th step
  bma3 = spatFilt.bms(dataBoston,burn=1000,WList=WL.boston, iter=5000, nmodel=20, g="bric", mcmc="rev.jump",logfile="",logstep=1000)
  image(bma3,cex=0.6) #showing the coefficient signs of the 20 best models and setting the font size of the labels in the plot to cex=0.6
  
  #using an interaction sampler for two interaction terms
  bma4 = spatFilt.bms(X.data=dataBoston,WList=WL.boston,burn=1000,iter=9000,start.value=0,mcmc="bd.int") 
  
  density(bma4,reg="NOX") # plot posterior density for covariate "NOX" with a grid
  grid()



