### Name: pmpW.bma
### Title: Posterior Model Probabilities of Weight Matrices
### Aliases: pmpW.bma
### Keywords: utilities

### ** Examples

   # sample BMA for boston housing data MCMC sampler
   data(dataBoston); data(WL.boston)
   bma1=spatFilt.bms(X.data=dataBoston,WList=WL.boston,burn=1e04,iter=1e04,nmodel=100)
   pmpW.bma(bma1)




